import { createContext } from "react";

const IncomeContext = createContext();

export default IncomeContext